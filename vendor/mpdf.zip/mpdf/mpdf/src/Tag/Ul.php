<?php

namespace Mpdf\Tag;

class Ul extends BlockTag
{


}
